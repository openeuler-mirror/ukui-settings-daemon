<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>KDSWidget</name>
    <message>
        <location filename="../kdswidget.ui" line="90"/>
        <source>System Screen Projection</source>
        <translation>系统投屏</translation>
    </message>
    <message>
        <location filename="../kdswidget.ui" line="121"/>
        <source>FirstOutput:</source>
        <translation>第一屏幕：</translation>
    </message>
    <message>
        <location filename="../kdswidget.cpp" line="161"/>
        <source>First Screen</source>
        <translation>仅显示电脑屏幕</translation>
    </message>
    <message>
        <location filename="../kdswidget.cpp" line="166"/>
        <source>Clone Screen</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../kdswidget.cpp" line="171"/>
        <source>Extend Screen</source>
        <translation>仅显示第二屏幕</translation>
    </message>
    <message>
        <location filename="../kdswidget.cpp" line="181"/>
        <source>Vice Screen</source>
        <translation>仅显示第二屏幕</translation>
    </message>
    <message>
        <location filename="../kdswidget.cpp" line="367"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../widget.ui" line="14"/>
        <source>KDS</source>
        <translation>系统投屏</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="95"/>
        <source>System Screen Projection</source>
        <translation>系统投屏</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="126"/>
        <source>FirstOutput:</source>
        <translation>第一屏幕：</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="137"/>
        <source>First Screen</source>
        <translation>仅显示电脑屏幕</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="145"/>
        <source>Clone Screen</source>
        <translation>镜像</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="153"/>
        <source>Extend Screen</source>
        <translation>扩展</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="161"/>
        <source>Vice Screen</source>
        <translation>仅显示第二屏幕</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="161"/>
        <source>None</source>
        <translation>无</translation>
    </message>
</context>
</TS>
