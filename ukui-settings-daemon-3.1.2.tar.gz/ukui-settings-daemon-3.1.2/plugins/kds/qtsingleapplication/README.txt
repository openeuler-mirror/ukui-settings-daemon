This is the src directory of the QtSingleApplication solution
integrated over from addons/main/utils/qtsingleapplication/src .

namespace.patch was applied to introduce the SharedTools namespace.

It additionally requires the QtLockedFile solution.

History:

16.05.2008 Integrated
