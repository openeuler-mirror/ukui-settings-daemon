This is the src directory of the  QtLockedFile
solution integrated over from addons/main/utils/qtlockedfile/src .

namespace.patch was applied to introduce the SharedTools namespace.

It is required by the QtSingleApplication solution.

History:

16.05.2008 Integrated
